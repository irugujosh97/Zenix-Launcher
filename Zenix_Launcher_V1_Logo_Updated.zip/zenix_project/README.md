# Zenix Launcher V1

A fresh Android launcher project branded **ZENIX LAUNCHER — JOSH X EDITOR**. The first version recreates the supplied Focus Frame reference screens as an independent implementation.

## Included in V1
- Home screen with a Focus Frame-inspired quick settings sheet
- Settings screen with the sections visible in the supplied references
- Navigation pages for theme, widgets, wallpaper, icon pack, desktop, app drawer, notifications, weather, font size, hidden apps, locked apps and app information
- Basic app drawer with installed-app launching and search
- Wallpaper selection from the gallery
- Preference persistence for basic appearance and launcher settings
- GitHub Actions workflow to build a debug APK

## Build
Open the project in Android Studio, or run:

```bash
gradle assembleDebug
```

The GitHub Actions workflow also builds the APK and uploads it as an artifact.

## Important V1 note
This is the initial functional foundation based on the three supplied screenshots. Features that need more reference screens or system-level Android permissions (for example full app-lock enforcement, notification-listener badges, third-party icon pack parsing, and real widget hosting) are represented by starter settings pages and will need dedicated implementation in later versions.


## ZENIX app branding
- The supplied JOSH X EDITOR / ZENIX LAUNCHER artwork is installed as the Android app launcher icon.
- Adaptive and legacy density icons are included, with safe padding to protect the neon ring from launcher icon masks.
- The untouched full-resolution artwork is retained at `app/src/main/res/drawable-nodpi/zenix_brand_logo.png`.
